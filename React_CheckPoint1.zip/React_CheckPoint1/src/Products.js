export let product ={
    name :"Pc Portable Asus VivoBook 15 X1502VA / i7 13è Gén / 16 Go / Win11 / Silver",
    price:"2 049,000 DT",
    description:'Ecran 15.6" LED Full HD - Processeur Intel Core i7-13700H Up to 5 GHz, 24 Mo de mémoire cache - Mémoire 16 Go - Disque SSD 512 Go M.2 NVMe - Carte graphique Intel Iris Xe -  WiFi - Bluetooth - HDMI - 1x USB 3.2 Type C - USB 3.2 - 1x HDMI - 1x Prise Jack 3.5 mm - Windows 11 - Couleur Silver - Garantie 1 an',
    image_url:"https://www.tunisianet.com.tn/346148-large/pc-portable-asus-vivobook-15-x1502va-i7-13e-gen-16-go-win11-silver.jpg",
    }