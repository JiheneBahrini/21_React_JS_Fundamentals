function Description({description}) {
    return (
        <div> <b> Product description : </b> {description}</div>
    )
  }
  export default Description