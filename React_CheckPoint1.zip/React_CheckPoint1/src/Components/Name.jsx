function Name({name}) {
    return (
        <div> <b> Product name : </b> {name} </div>
    )
  }
  export default Name