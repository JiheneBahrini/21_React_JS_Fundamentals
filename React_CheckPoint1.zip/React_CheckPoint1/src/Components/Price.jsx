function Price({price}) {
    return (
        <div> <b> Price : </b> {price} dinars </div>
    )
  }
  export default Price