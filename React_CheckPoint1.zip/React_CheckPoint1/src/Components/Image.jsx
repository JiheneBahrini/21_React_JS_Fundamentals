function Image({image_url}) {
    return (
        <div><img src={image_url} alt="Phone Image" width="400px" /></div>
    )
  }
  export default Image